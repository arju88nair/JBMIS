<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require '../vendor/autoload.php';
require '../includes/functions.php';

session_start();
$app = init();

$authenticate = function($request, $response, $next){
    if(!isset($_SESSION['user'])){
        return $response->withRedirect('/login/');
    }else{
        return $next($request, $response);
    }
};

$app->get('/login/',function(Request $request, Response $response){
    $response = $this->view->render($response, 'login.mustache');
    return $response;
});

$app->post('/login_validate', function(Request $request, Response $response){
    $data = $request->getParsedBody();
    $username = $data['username'];
    $password = $data['password'];
    if($username == 'jb_mis' && $password == 'misadmin'){
        $_SESSION['user'] = $username;
        return $response->withRedirect('/home/');
    }else{

    }
});

$app->get('/home/', function(Request $request, Response $response){
    $con = $this->db;
    function valData($val){
        if(isset($val) || !empty($val))
            return $val;
        else
            return 0;
    }
    $date_array = array();
    $date_array['day1'] = date('d-m-Y');
    $date_array['day2'] = date('d-m-Y', strtotime(' -1 day'));
    $date_array['day3'] = date('d-m-Y', strtotime(' -2 day'));
    $date_array['day4'] = date('d-m-Y', strtotime(' -3 day'));
    $date_array['day5'] = date('d-m-Y', strtotime(' -4 day'));
    $date_array['day6'] = date('d-m-Y', strtotime(' -5 day'));
    $date_array['day7'] = date('d-m-Y', strtotime(' -6 day'));

    $query = "SELECT ib.state,
                count(case when (trunc(mo.created_at)=trunc(sysdate) and mo.branch_id in (810,811)) then ib.id end) as day1_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate) and mo.branch_id not in (810,811)) then ib.id end) as day1_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-1) and mo.branch_id in (810,811)) then ib.id end) as day2_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-1) and mo.branch_id not in (810,811)) then ib.id end) as day2_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-2) and mo.branch_id in (810,811)) then ib.id end) as day3_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-2) and mo.branch_id not in (810,811)) then ib.id end) as day3_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-3) and mo.branch_id in (810,811)) then ib.id end) as day4_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-3) and mo.branch_id not in (810,811)) then ib.id end) as day4_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-4) and mo.branch_id in (810,811)) then ib.id end) as day5_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-4) and mo.branch_id not in (810,811)) then ib.id end) as day5_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-5) and mo.branch_id in (810,811)) then ib.id end) as day6_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-5) and mo.branch_id not in (810,811)) then ib.id end) as day6_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-6) and mo.branch_id in (810,811)) then ib.id end) as day7_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-6) and mo.branch_id not in (810,811)) then ib.id end) as day7_branch
                FROM opac.member_orders mo INNER JOIN opac.ibtrs ib ON ib.id = mo.ibtr_id
                WHERE mo.order_type= 'D' AND mo.flag_destination = 'S' group by ib.state";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($rows = oci_fetch_array($result, OCI_ASSOC)){
        $data_ibt[] = $rows;
    }

    $query = "SELECT ib.state,
                count(case when (trunc(mo.created_at)=trunc(sysdate) and mo.branch_id in (810,811)) then ib.id end) as day1_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate) and mo.branch_id not in (810,811)) then ib.id end) as day1_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-1) and mo.branch_id in (810,811)) then ib.id end) as day2_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-1) and mo.branch_id not in (810,811)) then ib.id end) as day2_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-2) and mo.branch_id in (810,811)) then ib.id end) as day3_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-2) and mo.branch_id not in (810,811)) then ib.id end) as day3_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-3) and mo.branch_id in (810,811)) then ib.id end) as day4_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-3) and mo.branch_id not in (810,811)) then ib.id end) as day4_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-4) and mo.branch_id in (810,811)) then ib.id end) as day5_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-4) and mo.branch_id not in (810,811)) then ib.id end) as day5_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-5) and mo.branch_id in (810,811)) then ib.id end) as day6_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-5) and mo.branch_id not in (810,811)) then ib.id end) as day6_branch,
                count(case when (trunc(mo.created_at)=trunc(sysdate-6) and mo.branch_id in (810,811)) then ib.id end) as day7_web,
                count(case when (trunc(mo.created_at)=trunc(sysdate-6) and mo.branch_id not in (810,811)) then ib.id end) as day7_branch
                FROM opac.member_orders mo INNER JOIN opac.ibtrs ib ON ib.id = mo.ibtr_id
                WHERE mo.order_type= 'D' AND mo.flag_destination = 'D' group by ib.state";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($rows = oci_fetch_array($result, OCI_ASSOC)){
        $data_dd[] = $rows;
    }

    return $this->view->render($response, 'home.mustache', ["ibt_7days" => $data_ibt,"dd_7days"=>$data_dd,"date_array"=>$date_array]);
})->add($authenticate);

$app->get('/dd/', function(Request $request, Response $response){
    return $this->view->render($response, 'dd_home.mustache');
})->add($authenticate);

//$app->get('/home_ibt_data/', function(Request $request, Response $response){
//    $con = $this->db;
//    $query = "select * from FN_Mis_Home_Ibt order by day7 desc";
//    $result = oci_parse($con, $query);
//    oci_execute($result);
//    while($rows = oci_fetch_array($result, OCI_ASSOC)){
//        $data[] = $rows;
//    }
//    echo json_encode($data);
//});

$app->get('/home_ibt_data/', function(Request $request, Response $response){
    $con = $this->db;
    $query = "SELECT ib.state,'web' as loc,
                    count(case when (trunc(mo.created_at)=trunc(sysdate) and mo.branch_id in (810,811)) then ib.id end) as day1,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-1) and mo.branch_id in (810,811)) then ib.id end) as day2,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-2) and mo.branch_id in (810,811)) then ib.id end) as day3,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-3) and mo.branch_id in (810,811)) then ib.id end) as day4,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-4) and mo.branch_id in (810,811)) then ib.id end) as day5,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-5) and mo.branch_id in (810,811)) then ib.id end) as day6,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-6) and mo.branch_id in (810,811)) then ib.id end) as day7
                    FROM opac.member_orders mo INNER JOIN opac.ibtrs ib ON ib.id = mo.ibtr_id
                    WHERE mo.order_type= 'D' AND mo.flag_destination = 'S' group by ib.state
                    union
                    SELECT ib.state,'branch',
                    count(case when (trunc(mo.created_at)=trunc(sysdate) and mo.branch_id not in (810,811)) then ib.id end) as day1,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-1) and mo.branch_id not in (810,811)) then ib.id end) as day2,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-2) and mo.branch_id not in (810,811)) then ib.id end) as day3,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-3) and mo.branch_id not in (810,811)) then ib.id end) as day4,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-4) and mo.branch_id not in (810,811)) then ib.id end) as day5,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-5) and mo.branch_id not in (810,811)) then ib.id end) as day6,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-6) and mo.branch_id not in (810,811)) then ib.id end) as day7
                    FROM opac.member_orders mo INNER JOIN opac.ibtrs ib ON ib.id = mo.ibtr_id
                    WHERE mo.order_type= 'D' AND mo.flag_destination = 'S' group by ib.state";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($rows = oci_fetch_array($result, OCI_ASSOC)){
        $data[] = $rows;
    }
    echo json_encode($data);
});

$app->get('/home_head_signups/', function(Request $request, Response $response){
    $con = $this->db;
    $query = "select count(*) signups  from signups s join jb_branches jb on s.branch_id=jb.id where created_at>=trunc(sysdate, 'mm')
and branchtype not in ('C') and s.REVERSAL_REASON_ID is null";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($rows = oci_fetch_array($result, OCI_ASSOC)){
        $data_signups = $rows['SIGNUPS'];
    }
    echo $data_signups;
});

$app->get('/home_head_collection/', function(Request $request, Response $response){
    $con = $this->db;
    $query_colc = "select count(case when owner_id=952 then booknumber end) as jb,
            count(case when owner_id!=952 then booknumber end) as franchisee
            from FN_book_Master where status not in ('Missing','Removed','Sell off','Lost','Returned to Publisher')";
    $result_colc = oci_parse($con, $query_colc);
    oci_execute($result_colc);
    while($row = oci_fetch_array($result_colc, OCI_ASSOC)){
        $colc[] = $row;

    }
    echo json_encode($colc);
});

$app->get('/home_head_circulation/', function(Request $request, Response $response){
    $con = $this->db;
    $query_borrow = "select count(case when owner_id=952 then booknumber end) as jb,
                count(case when owner_id!=952 then booknumber end) as franchisee
                from FN_book_Master where status in ('In Circulation')";
    $result_borrow = oci_parse($con, $query_borrow);
    oci_execute($result_borrow);
    while($row = oci_fetch_array($result_borrow, OCI_ASSOC)){
        $circulation[] = $row;
    }
    echo json_encode($circulation);
});

$app->get('/home_head_bookadded/', function(Request $request, Response $response){
    $con = $this->db;
    $query_colc_added = "select count(*) col_added from jb_books where insertdate is not null and insertdate>=trunc(sysdate,'mm')";
    $result_colc_added = oci_parse($con, $query_colc_added);
    oci_execute($result_colc_added);
    while($row = oci_fetch_array($result_colc_added, OCI_ASSOC)){
        $colc_added = $row['COL_ADDED'];
    }
    echo $colc_added;
});

$app->get('/home_head_reviews/', function(Request $request, Response $response){
    $con = $this->db;
    $query_review = "select count(*) reviews from reviews where created_at>=trunc(sysdate,'mm') ";
    $result_review = oci_parse($con, $query_review);
    oci_execute($result_review);
    while($row = oci_fetch_array($result_review, OCI_ASSOC)){
        $reviews = $row['REVIEWS'];
    }
    echo $reviews;
});

$app->get('/home_head_wishlist/', function(Request $request, Response $response){
    $con = $this->db;
    $query_wl = "select count(*) wl from wish_list_items where created_at>=trunc(sysdate,'mm')";
    $result_wl = oci_parse($con, $query_wl);
    oci_execute($result_wl);
    while($row = oci_fetch_array($result_wl, OCI_ASSOC)){
        $wl = $row['WL'];
    }
    echo $wl;
});

$app->get('/home_head_dd/', function(Request $request, Response $response){
    $con = $this->db;
    $query_dd = "SELECT count(case when branchtype='C' then mo.id end) corporate_dd,
        count(case when branchtype!='C' then mo.id end) branches_dd
        FROM opac.member_orders mo INNER JOIN opac.ibtrs ib ON ib.id = mo.ibtr_id
        join jb_branches jb on mo.branch_id=jb.id
        WHERE mo.order_type= 'D' AND mo.flag_destination = 'D'  and trunc(mo.updated_at)>=trunc(sysdate,'mm')";
    $result_dd = oci_parse($con, $query_dd);
    oci_execute($result_dd);
    while($row = oci_fetch_array($result_dd, OCI_ASSOC)){
        $dd[] = $row;
    }
    echo json_encode($dd);
});

$app->get('/home_head_ibtr/', function(Request $request, Response $response){
    $con = $this->db;
    $query_ibtr = "SELECT count(*) ibtr FROM opac.member_orders mo INNER JOIN opac.ibtrs ib ON ib.id = mo.ibtr_id
              WHERE mo.order_type= 'D' AND mo.flag_destination = 'S'  and trunc(mo.updated_at)>=trunc(sysdate,'mm')";
    $result_ibtr = oci_parse($con, $query_ibtr);
    oci_execute($result_ibtr);
    while($row = oci_fetch_array($result_ibtr, OCI_ASSOC)){
        $ibtr = $row['IBTR'];
    }
    echo $ibtr;
});

$app->get('/home_head_users/', function(Request $request, Response $response){
    $con = $this->db;
    $query_users = "select count(distinct membership_no) as users from fn_active_users";
    $result_users = oci_parse($con, $query_users);
    oci_execute($result_users);
    while($row = oci_fetch_array($result_users, OCI_ASSOC)){
        $users = $row['USERS'];
    }
    echo $users;
});

$app->get('/home_head_renewals/', function(Request $request, Response $response){
    $con = $this->db;
    $query_renewals = "select count(*) users from renewals where trunc(created_at)>=trunc(sysdate,'mm') and reversal_reason_id is null";
    $result_renewals = oci_parse($con, $query_renewals);
    oci_execute($result_renewals);
    while($row = oci_fetch_array($result_renewals, OCI_ASSOC)){
        $renewals = $row['USERS'];
    }
    echo $renewals;
});

$app->get('/home_dd_data/', function(Request $request, Response $response){
    $con = $this->db;
    $query = "SELECT ib.state,'web' as loc,
                    count(case when (trunc(mo.created_at)=trunc(sysdate) and mo.branch_id in (810,811)) then ib.id end) as day1,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-1) and mo.branch_id in (810,811)) then ib.id end) as day2,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-2) and mo.branch_id in (810,811)) then ib.id end) as day3,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-3) and mo.branch_id in (810,811)) then ib.id end) as day4,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-4) and mo.branch_id in (810,811)) then ib.id end) as day5,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-5) and mo.branch_id in (810,811)) then ib.id end) as day6,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-6) and mo.branch_id in (810,811)) then ib.id end) as day7
                    FROM opac.member_orders mo INNER JOIN opac.ibtrs ib ON ib.id = mo.ibtr_id
                    WHERE mo.order_type= 'D' AND mo.flag_destination = 'D' group by ib.state
                    union
                    SELECT ib.state,'branch',
                    count(case when (trunc(mo.created_at)=trunc(sysdate) and mo.branch_id not in (810,811)) then ib.id end) as day1,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-1) and mo.branch_id not in (810,811)) then ib.id end) as day2,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-2) and mo.branch_id not in (810,811)) then ib.id end) as day3,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-3) and mo.branch_id not in (810,811)) then ib.id end) as day4,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-4) and mo.branch_id not in (810,811)) then ib.id end) as day5,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-5) and mo.branch_id not in (810,811)) then ib.id end) as day6,
                    count(case when (trunc(mo.created_at)=trunc(sysdate-6) and mo.branch_id not in (810,811)) then ib.id end) as day7
                    FROM opac.member_orders mo INNER JOIN opac.ibtrs ib ON ib.id = mo.ibtr_id
                    WHERE mo.order_type= 'D' AND mo.flag_destination = 'D' group by ib.state";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($rows = oci_fetch_array($result, OCI_ASSOC)){
        $data[] = $rows;
    }
    echo json_encode($data);
});

$app->get('/home_branch_amount/', function(Request $request, Response $response){
    $con = $this->db;
    $query_amount_collected = "select branchname,nvl(amount_collected,0)-nvl(closure_amount,0) as final_amount from
                (select branchid,
                sum(case when type in ('signups','additionalcards','retention','lostcards','renewals','change_plans','bookpenalties','reopening') then jb_amount+branch_amount end) as amount_collected,
                sum(case when type='closures' then jb_amount+branch_amount end) as closure_amount
                from FN_COLLECTION_SUMMARY where trunc(tdate)>=trunc(sysdate,'mm')
                group by branchid) a join jb_branches jb on a.branchid=jb.id
                order by final_amount desc";
    $result_amount_collected = oci_parse($con,$query_amount_collected);
    oci_execute($result_amount_collected);
    while($rows = oci_fetch_array($result_amount_collected, OCI_ASSOC)){
        $amount_collected[] = $rows;
    }
    echo json_encode($amount_collected);
});

$app->get('/home_datewise_amount/', function(Request $request, Response $response){
    $con = $this->db;
    $query_amount_collected_date = "select * from fn_vCollectionDateWise order by tdate";
    $result_amount_collected_date = oci_parse($con,$query_amount_collected_date);
    oci_execute($result_amount_collected_date);
    while($rows = oci_fetch_array($result_amount_collected_date, OCI_ASSOC)){
        $amount_collected_date[] = $rows;
    }
    echo json_encode($amount_collected_date);
});

$app->get('/home_web_branch/', function(Request $request, Response $response){
    $con = $this->db;
    $query_web_bran = "select round(web/(web+branches)*100,1) as web,round(branches/(web+branches)*100,1) as branches from
            (select count(case when location in (810,811) then location end) as web,
            count(case when location not in (810,811) then location end) as branches
            from jbprod.books where status='D') t";
    $result_web_bran = oci_parse($con,$query_web_bran);
    oci_execute($result_web_bran);
    while($rows = oci_fetch_array($result_web_bran, OCI_ASSOC)){
        $data_web_signups[] = $rows;
    }
    echo json_encode($data_web_signups);
});

$app->get('/home_head_amount/', function(Request $request, Response $response){
    $con = $this->db;
    $query_ibtr = "select (jb_amount-closure) as jb_amount,branch_amount from
                (select sum(case when type!='closure' then jb_amount end) as jb_amount,sum(branch_amount) branch_amount,
                sum(case when type='closure' then jb_amount end) as closure
                from fn_collection_summary where tdate>=trunc(sysdate,'mm'))";
    $result_ibtr = oci_parse($con, $query_ibtr);
    oci_execute($result_ibtr);
    while($row = oci_fetch_array($result_ibtr, OCI_ASSOC)){
        $payment[] = $row;
    }
    echo json_encode($payment);
});

$app->get('/ageing/', function(Request $request, Response $response){
    $con = $this->db;
    function hoursToDays($val){
        if($val == null || $val == ''){
            return '';
        }elseif($val<24){
            return $val.' Hrs';
        }else{
            $val_day = round(floor($val / 24),0);
            $val_hr = $val % 24;
            return $val_day.' Days '.$val_hr.' Hrs';
        }
    }
    $query = "select branch_id,branchname,order_type,
                nvl(round(avg(new_assigned_diff),0),0) new_assigned_diff,
                nvl(round(avg(new_fulfilled_diff),0),0) new_fulfilled_diff,
                nvl(round(avg(new_dispatched_diff),0),0) new_dispatched_diff,
                nvl(round(avg(new_received_diff),0),0) new_received_diff,
                nvl(round(avg(new_intransit_diff),0),0) new_intransit_diff,
                nvl(round(avg(new_completed_diff),0),0)  new_completed_diff
                from FN_ageing fa join jb_branches jb on fa.branch_id=jb.id where order_type='DD'
                group by branch_id,branchname,order_type order by new_completed_diff desc";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($rows = oci_fetch_array($result, OCI_ASSOC)){
        $data_dd['BRANCHNAME'] = $rows['BRANCHNAME'];
        if(isset($rows['NEW_ASSIGNED_DIFF']))
            $data_dd['NEW_ASSIGNED_DIFF'] = hoursToDays($rows['NEW_ASSIGNED_DIFF']);
        if(isset($rows['NEW_FULFILLED_DIFF']))
            $data_dd['NEW_FULFILLED_DIFF'] = hoursToDays($rows['NEW_FULFILLED_DIFF']);
        if(isset($rows['NEW_DISPATCHED_DIFF']))
            $data_dd['NEW_DISPATCHED_DIFF'] = hoursToDays($rows['NEW_DISPATCHED_DIFF']);
        if(isset($rows['NEW_RECEIVED_DIFF']))
            $data_dd['NEW_RECEIVED_DIFF'] = hoursToDays($rows['NEW_RECEIVED_DIFF']);
        if(isset($rows['NEW_RECEIVED_DIFF']))
            $data_dd['NEW_INTRANSIT_DIFF'] = hoursToDays($rows['NEW_RECEIVED_DIFF']);
        if(isset($rows['NEW_COMPLETED_DIFF']))
            $data_dd['NEW_COMPLETED_DIFF'] = hoursToDays($rows['NEW_COMPLETED_DIFF']);
        $data_dd_new[] = $data_dd;
    }
    $query = "select branch_id,branchname,order_type,
                nvl(round(avg(new_assigned_diff),0),0) new_assigned_diff,
                nvl(round(avg(new_fulfilled_diff),0),0) new_fulfilled_diff,
                nvl(round(avg(new_dispatched_diff),0),0) new_dispatched_diff,
                nvl(round(avg(new_received_diff),0),0) new_received_diff,
                nvl(round(avg(new_intransit_diff),0),0) new_intransit_diff,
                nvl(round(avg(new_completed_diff),0),0)  new_completed_diff
                from FN_ageing fa join jb_branches jb on fa.branch_id=jb.id where order_type='IBTR'
                group by branch_id,branchname,order_type order by new_completed_diff desc";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($rows = oci_fetch_array($result, OCI_ASSOC)){
        $data_ibtr['BRANCHNAME'] = $rows['BRANCHNAME'];
        if(isset($rows['NEW_ASSIGNED_DIFF']))
            $data_ibtr['NEW_ASSIGNED_DIFF'] = hoursToDays($rows['NEW_ASSIGNED_DIFF']);
        if(isset($rows['NEW_FULFILLED_DIFF']))
            $data_ibtr['NEW_FULFILLED_DIFF'] = hoursToDays($rows['NEW_FULFILLED_DIFF']);
        if(isset($rows['NEW_DISPATCHED_DIFF']))
            $data_ibtr['NEW_DISPATCHED_DIFF'] = hoursToDays($rows['NEW_DISPATCHED_DIFF']);
        if(isset($rows['NEW_RECEIVED_DIFF']))
            $data_ibtr['NEW_RECEIVED_DIFF'] = hoursToDays($rows['NEW_RECEIVED_DIFF']);
        if(isset($rows['NEW_RECEIVED_DIFF']))
            $data_ibtr['NEW_INTRANSIT_DIFF'] = hoursToDays($rows['NEW_RECEIVED_DIFF']);
        if(isset($rows['NEW_COMPLETED_DIFF']))
            $data_ibtr['NEW_COMPLETED_DIFF'] = hoursToDays($rows['NEW_COMPLETED_DIFF']);
        $data_ibtr_new[] = $data_ibtr;
    }
    return $this->view->render($response, 'ageing.mustache',['ageing_dd'=>$data_dd_new,'ageing_ibtr'=>$data_ibtr_new]);
});

$app->get('/home_signups/', function(Request $request, Response $response){
    $con = $this->db;
    $query = "select trunc(created_at) dt,count(*) signups from signups where trunc(created_at)>=sysdate-30 group by trunc(created_at) order by trunc(created_at)";
    $result = oci_parse($con, $query);
    oci_execute($result);
    $year = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
    while($row = oci_fetch_array($result)){
        $data = '';
        $dt = '';
        $dt = explode('-',$row['DT']);
        $data[] = 'Date.UTC(20'.$dt[2].','.array_search($dt[1],$year).','.$dt[0].')';
        $data[] = $row['SIGNUPS'];
        $data_new[] = $data;
    }
    echo json_encode($data_new);
})->add($authenticate);

$app->get('/home_category/', function(Request $request, Response $response){
    $con = $this->db;
    $query = "select * from
        (select categoryname,count(*) rented from fn_book_master fbm join rentals r on fbm.booknumber=r.book_id
        where trunc(created_at)>=sysdate-30 group by categoryname order by rented desc) where rownum<=10 and categoryname is not null";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($row = oci_fetch_assoc($result)){
        $data[] = $row;
    }
    echo json_encode($data);
});

$app->any('/collection/', function(Request $request, Response $response){
    $con = $this->db;
    $data = $request->getParsedBody();
    $data_collection = [];
    if(isset($data['from']))
        $from = $data['from'];
    else
        $from =  date('01-M-Y');
    if(isset($data['to']))
        $to = $data['to'];
    else
        $to = date('d-M-Y');
    $query = "select branchname,nvl(signups,0) signups,nvl(renewals,0) renewals,nvl(others,0) others,
                    nvl(total,0) mtd_total,nvl(jb_total,0) mtd_jb_total,nvl(branch_total,0) mtd_branch_total,
                    nvl(ytd_total,0) ytd_total,nvl(ytd_jb_total,0) ytd_jb_total,nvl(ytd_branch_total,0) ytd_branch_total,nvl(stc,0) stc from
                    (select branchid,ytd_total,ytd_jb_total,ytd_branch_total from
                    (select branchid,
                    sum(jb_amount)+sum(branch_amount) as ytd_total,
                    sum(jb_amount) as ytd_jb_total,
                    sum(branch_amount) as ytd_branch_total
                    from fn_collection_summary
                    where tdate between (select '01-Apr-'||case when to_number(to_char(sysdate, 'mm')) > 3 then to_number(to_char(sysdate, 'YYYY')) else
                    to_number(to_char(sysdate, 'YYYY'))-1 end as from_date from dual) and '$to'
                    group by branchid)) a
                    left join
                    (select branchid,signups,renewals,nvl(others,0)-nvl(branch_closure,0) as others,total,jb_total,branch_total from
                    (select branchid,
                    sum(case when type='signups' then jb_amount+branch_amount end) as signups,
                    sum(case when type='renewals' then jb_amount+branch_amount end) as renewals,
                    sum(case when type in ('retention','reopenings','additional_cards','book_penalties','settled_dues','delivery_fees','lostcards','change_plans') then jb_amount+branch_amount end) as others,
                    sum(case when type='closure' then jb_amount+branch_amount end) as branch_closure,
                    sum(jb_amount)+sum(branch_amount) as total,
                    sum(jb_amount) as jb_total,
                    sum(branch_amount) as branch_total
                    from fn_collection_summary
                    where tdate between '$from' and '$to' group by branchid)) b
                    on a.branchid=b.branchid
                    left join
                    (select branchid,round(nvl(sum(books_circulation),0)/nvl(sum(members_count),0),1) as stc
                    from fn_circulation_members_details where trunc(tdate) between '$from' and '$to' group by branchid) c
                    on a.branchid=c.branchid join jb_branches jb on a.branchid=jb.id order by branchname";
    $result = oci_parse($con, $query);
    oci_execute($result);
    $signups=$renewal=$others=$mtd_total=$mtd_jb=$mtd_br=$ytd_total=$ytd_jb=$ytd_br=0;
    while($row = oci_fetch_assoc($result)){
        $data_collection[] = $row;
        $signups = $signups + $row['SIGNUPS'];
        $renewal = $renewal + $row['RENEWALS'];
        $others = $others + $row['OTHERS'];
        $mtd_total = $mtd_total + $row['MTD_TOTAL'];
        $mtd_jb = $mtd_jb + $row['MTD_JB_TOTAL'];
        $mtd_br = $mtd_br + $row['MTD_BRANCH_TOTAL'];
        $ytd_total = $ytd_total + $row['YTD_TOTAL'];
        $ytd_jb = $ytd_jb + $row['YTD_JB_TOTAL'];
        $ytd_br = $ytd_br + $row['YTD_BRANCH_TOTAL'];
    }
    return $this->view->render($response, 'collection.mustache',['collection'=>$data_collection,'jb_sign'=>$signups,
    'jb_renewal'=>$renewal,'others'=>$others,'mtd_total'=>$mtd_total,'mtd_jb'=>$mtd_jb,'mtd_br'=>$mtd_br,'ytd_total'=>$ytd_total,
    'ytd_jb'=>$ytd_jb,'ytd_br'=>$ytd_br,'date_show'=>1,'from'=>$from,'to'=>$to]);
})->add($authenticate);

$app->get('/home_datewise_signups/', function(Request $request, Response $response){
    $con = $this->db;
    $query = "select * from fn_vSignupsDateWise order by tdate";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($row = oci_fetch_assoc($result)){
        $data_final[] = $row;
    }
    echo json_encode($data_final);
});

$app->get('/home_datewise_renewals/', function(Request $request, Response $response){
    $con = $this->db;
    $query = "select * from fn_vRenewalsDateWise order by tdate";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($row = oci_fetch_assoc($result)){
        $data_final[] = $row;
    }
    echo json_encode($data_final);
});

$app->get('/home_head_otrcount/',function(Request $request, Response $response){
    $con = $this->db;
    $query = "select sum(total_renewal) total,sum(expiring_member_count) expiry from otrs where track_month_date=trunc(sysdate,'mm')";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($row = oci_fetch_assoc($result)){
        $data_final[] = $row;
    }
    echo json_encode($data_final);

});

$app->get('/home_head_otrvalue/',function(Request $request, Response $response){
    $con = $this->db;
    $query = "select sum(renewal_value)+sum(change_plan_value) as total_val from otrs where track_month_date=trunc(sysdate,'mm')";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($row = oci_fetch_assoc($result)){
        $data_final = $row['TOTAL_VAL'];
    }
    echo $data_final;

});

$app->get('/logout/', function(Request $request, Response $response){
    unset($_SESSION['user']);
    return $response->withRedirect('/login/');
});

$app->get('/otr/', function(Request $request, Response $response){
    $con = $this->db;
    $from =  date('01-M-Y');
    $to = date('d-M-Y');
    $query = "select branchname,
                sum(case when type='signups' then jb_amount end) as jb_signups,
                sum(case when type='signups' then branch_amount end) as branch_signups,
                sum(case when type='renewals' then jb_amount end) as jb_renewals,
                sum(case when type='renewals' then branch_amount end) as branch_renewals,
                sum(case when type='retention' then jb_amount end) as jb_retention,
                sum(case when type='retention' then branch_amount end) as branch_retention,
                sum(case when type='reopenings' then jb_amount end) as jb_reopenings,
                sum(case when type='reopenings' then branch_amount end) as branch_reopenings,
                sum(case when type='additional_cards' then jb_amount end) as jb_additional_cards,
                sum(case when type='additional_cards' then branch_amount end) as branch_additional_cards,
                sum(case when type='book_penalties' then jb_amount end) as jb_book_penalties,
                sum(case when type='book_penalties' then branch_amount end) as branch_book_penalties,
                sum(case when type='settled_dues' then jb_amount end) as jb_settled_dues,
                sum(case when type='settled_dues' then branch_amount end) as branch_settled_dues,
                sum(case when type='delivery_fees' then jb_amount end) as jb_delivery_fees,
                sum(case when type='delivery_fees' then branch_amount end) as branch_delivery_fees,
                sum(case when type='lostcards' then jb_amount end) as jb_lostcards,
                sum(case when type='lostcards' then branch_amount end) as branch_lostcards,
                sum(case when type='change_plans' then jb_amount end) as jb_change_plans,
                sum(case when type='change_plans' then branch_amount end) as branch_change_plans,
                sum(case when type='closure' then jb_amount end) as jb_closure,
                sum(case when type='closure' then branch_amount end) as branch_closure
                from fn_collection_summary fcs join jb_branches jb on fcs.branchid=jb.id
                where tdate between '$from' and '$to' group by branchname order by branchname";
    $result = oci_parse($con, $query);
    oci_execute($result);
    $jb_signups=$jb_renewal=$jb_rentention=$jb_reopen=$jb_ac=$jb_bp=$jb_sd=$jb_df=$jb_lc=$jb_cp=$jb_cl=$jb_total=0;
    $b_signups=$b_renewal=$b_rentention=$b_reopen=$b_ac=$b_bp=$b_sd=$b_df=$b_lc=$b_cp=$b_cl=$b_total=0;
    while($row = oci_fetch_assoc($result)){
        $data_collection[] = $row;
        $jb_signups = $jb_signups + $row['JB_SIGNUPS'];
        $jb_renewal = $jb_renewal + $row['JB_RENEWALS'];
        $jb_rentention = $jb_rentention + $row['JB_RETENTION'];
        $jb_reopen = $jb_reopen + $row['JB_REOPENINGS'];
        $jb_ac = $jb_ac + $row['JB_ADDITIONAL_CARDS'];
        $jb_bp = $jb_bp + $row['JB_BOOK_PENALTIES'];
        $jb_sd = $jb_sd + $row['JB_SETTLED_DUES'];
        $jb_df = $jb_df + $row['JB_DELIVERY_FEES'];
        $jb_lc = $jb_lc + $row['JB_LOSTCARDS'];
        $jb_cp = $jb_cp + $row['JB_CHANGE_PLANS'];
        $jb_cl = $jb_cl + $row['JB_CLOSURE'];
        $b_signups = $b_signups + $row['BRANCH_SIGNUPS'];
        $b_renewal = $b_renewal + $row['BRANCH_RENEWALS'];
        $b_rentention = $b_rentention + $row['BRANCH_RETENTION'];
        $b_reopen = $b_reopen + $row['BRANCH_REOPENINGS'];
        $b_ac = $b_ac + $row['BRANCH_ADDITIONAL_CARDS'];
        $b_bp = $b_bp + $row['BRANCH_BOOK_PENALTIES'];
        $b_sd = $b_sd + $row['BRANCH_SETTLED_DUES'];
        $b_df = $b_df + $row['BRANCH_DELIVERY_FEES'];
        $b_lc = $b_lc + $row['BRANCH_LOSTCARDS'];
        $b_cp = $b_cp + $row['BRANCH_CHANGE_PLANS'];
        $b_cl = $b_cl + $row['BRANCH_CLOSURE'];
    }
    $jb_total = ($jb_signups+$jb_renewal+$jb_rentention+$jb_reopen+$jb_ac+$jb_bp+$jb_sd+$jb_df+$jb_lc+$jb_cp)-$jb_cl;
    $b_total = ($b_signups+$b_renewal+$b_rentention+$b_reopen+$b_ac+$b_bp+$b_sd+$b_df+$b_lc+$b_cp)-$b_cl;
//    echo json_encode($data);DIE;
    return $this->view->render($response, 'collection.mustache',['collection'=>$data_collection,'jb_sign'=>$jb_signups,
        'jb_renewal'=>$jb_renewal,'jb_rentention'=>$jb_rentention,'jb_reopen'=>$jb_reopen,'jb_ac'=>$jb_ac,'jb_bp'=>$jb_bp,
        'jb_sd'=>$jb_sd,'jb_df'=>$jb_df,'jb_lc'=>$jb_lc,'jb_cp'=>$jb_cp,'jb_cl'=>$jb_cl,'jb_total'=>$jb_total,'b_sign'=>$b_signups,
        'b_renewal'=>$b_renewal,'b_rentention'=>$b_rentention,'b_reopen'=>$b_reopen,'b_ac'=>$b_ac,'b_bp'=>$b_bp,
        'b_sd'=>$b_sd,'b_df'=>$b_df,'b_lc'=>$b_lc,'b_cp'=>$b_cp,'b_cl'=>$b_cl,'b_total'=>$b_total]);
})->add($authenticate);

$app->get('/home_head_summary/',function(Request $request, Response $response){
    $con = $this->db;
    $query = "select sum(web_perfomance) web_perfomance,sum(branch_perfomance) branch_perfomance,sum(signups) signups,sum(renewals) renewals,
        sum(active_users) active_users,sum(otr) otr,sum(otr_collection) otr_collection,sum(DD_CORPORATE) DD_CORPORATE,
        sum(DD_BRANCH) DD_BRANCH,sum(IBT) IBT,sum(CIRCULATION_JB) CIRCULATION_JB,sum(CIRCULATION_FRANCHISEE) CIRCULATION_FRANCHISEE,
        sum(COLLECTION_JB) COLLECTION_JB,sum(COLLECTION_FRANCHISE) COLLECTION_FRANCHISE,sum(BOOKS_ADDED) BOOKS_ADDED,
        sum(SHARE_JB) SHARE_JB,sum(SHARE_FRANCHISE) SHARE_FRANCHISE,sum(OTR_EXPIRY) OTR_EXPIRY from fn_home_page_summary
        where trunc(tdate)>=trunc(sysdate,'mm')";
    $result = oci_parse($con, $query);
    oci_execute($result);
    while($row = oci_fetch_assoc($result)){
        $data_final[] = $row;
    }
    echo json_encode($data_final);

});

$app->run();

?>